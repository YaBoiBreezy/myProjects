#Assignment 1 by Alex Breeze
#Displays an equation, then solves it and prints the solution
print('(2.019x10^-9 x 5.76x10^-7) / (7.16x10^-4 + 9.23x10^-7)')
print(((2.019*10**-9) * (5.76*10**-7)) / (7.16*10**-4 + 9.23*10**-7))