#Assignment 1 p2 by Alex Breeze
distance=float(input('Enter a distance in cm: ')) #Get distance
print(f"{distance}cm is approximately {int(distance/30.48)}'{distance%30.48/2.54:.0f}\".")
#print distance/feet, and the remainder/inches
