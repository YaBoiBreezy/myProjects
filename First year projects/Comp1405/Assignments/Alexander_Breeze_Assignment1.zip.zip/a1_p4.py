#Assignment 1, p4 by Alex Breeze
num1=int(input('1. Enter a number: '))
num2=int(input('2. Enter a number: '))
num3=int(input('3. Enter a number: '))
num4=int(input('4. Enter a number: '))
#biggestDifference=biggest#-smallest#
print(f'The largest difference is: {max(num1,num2,num3,num4)-min(num1,num2,num3,num4)}')