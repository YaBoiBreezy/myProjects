package PackageThingy;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.scene.input.MouseEvent;
import javafx.event.*;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import javafx.scene.control.Label;
import java.util.ArrayList;

public class ElectronicStoreApp extends Application {
    private ElectronicStore model;
    private ElectronicStoreView view;
    private ArrayList<Product> BeingBought;
    private ArrayList<Product> storeStockProducts;


    public void start(Stage stage){
        model = ElectronicStore.createStore();
        view = new ElectronicStoreView();
        BeingBought = new ArrayList<Product>();      //store product objects of things to buy, in parallel with CurrentCart<String>
        storeStockProducts = new ArrayList<Product>();       //stores product objects of things that can be bought, in parallel with StoreStock<String>

        for (int x=0;x<model.getCurProducts();x++){
            storeStockProducts.add(model.stock[x]);
            view.StoreStock.getItems().add(model.stock[x].toString());
        }
        view.MostPopList.getItems().add(model.stock[0].toString());
        view.MostPopList.getItems().add(model.stock[1].toString());
        view.MostPopList.getItems().add(model.stock[2].toString());
        //view.start(stage);

        view.AddToCart.setOnAction(new EventHandler<ActionEvent>(){
            public void handle(ActionEvent actionEvent){
                int index=view.StoreStock.getSelectionModel().getSelectedIndex();
                BeingBought.add(storeStockProducts.get(index));
                storeStockProducts.get(index).setStockQuantity(-1);

                model.setCartValue(model.getCartValue()+storeStockProducts.get(index).getPrice());
                String a=String.format("%.2f",model.getCartValue());
                view.CurrentCartLabel.setText("Current Cart ($"+a+"):");

                if (storeStockProducts.get(index).getStockQuantity()==0){  //out of that product
                    storeStockProducts.remove(index);
                    System.out.println("Out");
                }
                updateLists(false);

                view.CompleteSale.setDisable(false);
                view.AddToCart.setDisable(true);
            }
        });
        view.RemoveFromCart.setOnAction(new EventHandler<ActionEvent>() {
            public void handle(ActionEvent actionEvent) {
                int index=view.CurrentCart.getSelectionModel().getSelectedIndex();
                if (storeStockProducts.contains(BeingBought.get(index))){
                    storeStockProducts.get(storeStockProducts.indexOf(BeingBought.get(index))).setStockQuantity(-1);
                }
                else{
                    storeStockProducts.add(BeingBought.get(index));
                }

                model.setCartValue(model.getCartValue()-BeingBought.get(index).getPrice());
                String a=String.format("%.2f",model.getCartValue());
                view.CurrentCartLabel.setText("Current Cart ($"+a+"):");

                BeingBought.remove(BeingBought.get(index));
                updateLists(false);

                if (BeingBought.size()==0){
                    view.CompleteSale.setDisable(true);
                }
                view.RemoveFromCart.setDisable(true);
            }
        });
        view.StoreStock.setOnMouseClicked(new EventHandler<MouseEvent>() {
            public void handle(MouseEvent mouseEvent) {
                if (view.StoreStock.getSelectionModel().getSelectedIndex()!=-1){
                    view.AddToCart.setDisable(false);
                    view.RemoveFromCart.setDisable(true);
                }
            }
        });
        view.CurrentCart.setOnMouseClicked(new EventHandler<MouseEvent>() {
            public void handle(MouseEvent mouseEvent) {
                if (view.CurrentCart.getSelectionModel().getSelectedIndex()!=-1){
                    view.AddToCart.setDisable(true);
                    view.RemoveFromCart.setDisable(false);
                }
            }
        });
        view.CompleteSale.setOnAction(new EventHandler<ActionEvent>() {
            public void handle(ActionEvent actionEvent) {
                model.setSales(model.getSales()+1);
                model.setRevenue(model.getRevenue()+model.getCartValue());
                view.Sales.setText(Integer.toString(model.getSales()));
                String a=String.format("%.2f",model.getRevenue());
                view.Revenue.setText(a);
                a=String.format("%.2f",model.getRevenue()/model.getSales());
                view.Sale.setText(a);
                model.setCartValue(0.0);
                view.CurrentCartLabel.setText("Current Cart ($0.00):");
                for (int x=0;x<BeingBought.size();x++){
                    for (int y=0;y<model.getCurProducts();y++){
                        if (BeingBought.get(x)==model.stock[y]){
                            model.stock[y].setSoldQuantity(1);
                        }
                    }
                }
                BeingBought.clear();
                view.AddToCart.setDisable(true);
                view.RemoveFromCart.setDisable(true);
                view.CompleteSale.setDisable(true);
                updateLists(true);
            }
        });
        view.ResetStore.setOnAction(new EventHandler<ActionEvent>() {
            public void handle(ActionEvent actionEvent) {
                model = ElectronicStore.createStore();
                view.AddToCart.setDisable(true);
                view.RemoveFromCart.setDisable(true);
                view.CompleteSale.setDisable(true);
                view.MostPopList.getItems().clear();
                view.CurrentCart.getItems().clear();
                view.StoreStock.getItems().clear();

                view.Sales.setText(Integer.toString(model.getSales()));
                view.Revenue.setText(Double.toString(model.getRevenue()));
                view.Sale.setText(Double.toString(model.getRevenue()/model.getSales()));
                view.CurrentCartLabel.setText("Current Cart ($"+model.getCartValue()+"):");

                BeingBought.clear();
                storeStockProducts.clear();

                for (int x=0;x<model.getCurProducts();x++){
                    storeStockProducts.add(model.stock[x]);
                    view.StoreStock.getItems().add(model.stock[x].toString());
                }
                view.MostPopList.getItems().add(model.stock[0].toString());
                view.MostPopList.getItems().add(model.stock[1].toString());
                view.MostPopList.getItems().add(model.stock[2].toString());
            }
        });
        stage.setTitle("Electronic Store View - "+model.getName());
        stage.setScene(new Scene(view,800,400));
        stage.setResizable(false);
        stage.show();
    }
    public void updateLists(Boolean soldStuff){
        view.StoreStock.getItems().clear();
        for (int x=0;x<storeStockProducts.size();x++){
            view.StoreStock.getItems().add(storeStockProducts.get(x).toString());
        }
        view.CurrentCart.getItems().clear();
        for (int x=0;x<BeingBought.size();x++){
            view.CurrentCart.getItems().add(BeingBought.get(x).toString());
        }
        if(soldStuff){//get best sellers
            view.MostPopList.getItems().clear();
            int[] bestSold = {-1,-1,-1};
            int[] bestSoldIndex = {-1,-1,-1};
            for (int y=0;y<3;y++){
                for (int x=0;x<model.getCurProducts();x++){
                    if (model.stock[x].getSoldQuantity()>bestSold[y] && bestSoldIndex[0]!=x && bestSoldIndex[1]!=x){
                        bestSold[y]=model.stock[x].getSoldQuantity();
                        bestSoldIndex[y]=x;
                    }
                }
            }
            for (int x=0;x<3;x++){
                view.MostPopList.getItems().add(model.stock[bestSoldIndex[x]].toString());
            }
        }
    }
}
//stage.setTitle("Electronic Store View - "+model.getName());