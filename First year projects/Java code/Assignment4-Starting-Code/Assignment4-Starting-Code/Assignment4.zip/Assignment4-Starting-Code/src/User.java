import java.util.ArrayList;

public class User {
  private String     userName;
  private boolean    online;
  private ArrayList<Song> songList;

  public User()  { this(""); }
  
  public User(String u)  {
    userName = u;
    online = false;
    songList = new ArrayList<Song>();
  }
  
  public String getUserName() { return userName; }
  public boolean isOnline() { return online; }
  public ArrayList<Song> getSongList() {return songList;}
  
  public String toString()  {
    String s = "" + userName + ": "+songList.size()+" songs (";
    if (!online) s += "not ";
    return s + "online)";
  }

  public void addSong(Song s){
    songList.add(s);
    s.setOwner(this);
  }

  public int totalSongTime(){
    int totalTime=0;
    for (int x=0;x<songList.size();x++){
      totalTime+=songList.get(x).getDuration();
    }
    return totalTime;
  }

  public void register(MusicExchangeCenter m){
    m.registerUser(this);
  }

  public ArrayList<String> requestCompleteSonglist(MusicExchangeCenter m){
    ArrayList<String> songNames=new ArrayList<String>();
    songNames.add("TITLE                       ARTIST          TIME   OWNER");
    ArrayList<Song> songs=m.allAvailableSongs();
    int x=1;
    for (Song song:songs){
      songNames.add(x+". "+String.format("%-25s%-15s%2d%-1s%02d%-1s%-15s",song.getTitle(),song.getArtist(),song.getMinutes(),":",song.getSeconds(),"   ",song.getOwner()));      x+=1;
    }
    return songNames;
  }

  public ArrayList<String> requestSonglistByArtist(MusicExchangeCenter m, String artist){
    ArrayList<String> songNames=new ArrayList<String>();
    songNames.add("TITLE                       ARTIST          TIME   OWNER");
    ArrayList<Song> allSongs = m.allAvailableSongs();
    int x=1;
    for (Song song:allSongs){
      if (song.getArtist().equals(artist)){
        songNames.add(x+". "+String.format("%-25s%-15s%2d%-1s%02d%-1s%-15s",song.getTitle(),song.getArtist(),song.getMinutes(),":",song.getSeconds(),"   ",song.getOwner()));
        x+=1;
      }
    }
    return songNames;
  }

  public void logon(){
    this.online=true;
  }

  public void logoff(){
    this.online=false;
  }

  public void downloadSong(MusicExchangeCenter m, String title, String ownerName){
    Song song = m.getSong(title, ownerName);
    if (song!=null){
      songList.add(song);
    }
  }
}